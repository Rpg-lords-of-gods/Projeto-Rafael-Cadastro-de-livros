from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import openpyxl
import difflib
import os

app = Flask(__name__)
app.secret_key = "dev"  # usado para mensagens flash

EXCEL_FILE = "livros.xlsx"
HEADERS = ["Título", "Autor", "Ano", "Preço", "Quantidade"]

# --- Funções auxiliares ---
def get_sheet():
    """Abre ou cria a planilha Excel"""
    if os.path.exists(EXCEL_FILE):
        wb = openpyxl.load_workbook(EXCEL_FILE)
        sh = wb.active
    else:
        wb = openpyxl.Workbook()
        sh = wb.active
        sh.title = "Livros"
        sh.append(HEADERS)
        wb.save(EXCEL_FILE)
    return wb, sh

def append_livro(titulo, autor, ano, preco, quantidade):
    """Salva um novo livro no Excel"""
    wb, sh = get_sheet()
    sh.append([titulo, autor, ano, preco, quantidade])
    wb.save(EXCEL_FILE)

# --- Rotas principais ---
@app.route("/")
def index():
    return render_template("index.html")

# Cadastro via formulário HTML
@app.route("/cadastrar", methods=["GET", "POST"])
def cadastrar():
    if request.method == "POST":
        titulo = request.form.get("titulo", "").strip()
        autor = request.form.get("autor", "").strip()
        ano = request.form.get("ano", "").strip()
        preco = request.form.get("preco", "").strip().replace(",", ".")
        quantidade = request.form.get("quantidade", "").strip()

        erros = []
        if not titulo: erros.append("Título é obrigatório.")
        if not autor: erros.append("Autor é obrigatório.")
        if not (ano.isdigit() and len(ano) == 4): erros.append("Ano inválido (4 dígitos).")
        try:
            preco_val = float(preco)
            if preco_val < 0: erros.append("Preço não pode ser negativo.")
        except:
            erros.append("Preço inválido.")
        if not quantidade.isdigit() or int(quantidade) < 0:
            erros.append("Quantidade inválida.")

        if erros:
            for e in erros:
                flash(e, "erro")
            return render_template("cadastrar.html", form=request.form)

        append_livro(titulo, autor, int(ano), float(preco), int(quantidade))
        flash(f"Livro '{titulo}' cadastrado com sucesso!", "sucesso")
        return redirect(url_for("cadastrar"))

    return render_template("cadastrar.html", form={})

# Cadastro via API (JavaScript)
@app.route("/api/cadastrar", methods=["POST"])
def api_cadastrar():
    data = request.get_json() or {}
    titulo = (data.get("titulo") or "").strip()
    autor = (data.get("autor") or "").strip()
    ano = (data.get("ano") or "").strip()
    preco = (data.get("preco") or "").strip().replace(",", ".")
    quantidade = (data.get("quantidade") or "").strip()

    erros = []
    if not titulo:
        erros.append("Título é obrigatório.")
    if not autor:
        erros.append("Autor é obrigatório.")
    if not (ano.isdigit() and len(ano) == 4):
        erros.append("Ano inválido (4 dígitos).")
    try:
        preco_val = float(preco)
        if preco_val < 0:
            erros.append("Preço não pode ser negativo.")
    except:
        erros.append("Preço inválido.")
    if not quantidade.isdigit() or int(quantidade) < 0:
        erros.append("Quantidade inválida.")

    if erros:
        return jsonify({"status": "erro", "mensagens": erros}), 400

    append_livro(titulo, autor, int(ano), float(preco), int(quantidade))
    return jsonify({"status": "sucesso", "mensagem": f"Livro '{titulo}' cadastrado com sucesso!"})

# Listar livros
@app.route("/listar")
def listar():
    wb, sh = get_sheet()
    livros = []

    for i, row in enumerate(sh.iter_rows(values_only=True), start=1):
        if i == 1:
            continue
        livros.append(row)

    return render_template("listar.html", livros=livros, headers=HEADERS)

# API para listar livros em JSON
@app.route("/api/listar")
def api_listar():
    wb, sh = get_sheet()
    livros = []
    for i, row in enumerate(sh.iter_rows(values_only=True), start=1):
        if i == 1:  # pula cabeçalho
            continue
        livros.append(row)
    return jsonify(livros)


# Buscar livros
@app.route("/buscar", methods=["GET", "POST"])
def buscar():
    resultados = []
    termo = ""
    filtro = "titulo"

    if request.method == "POST":
        termo = request.form.get("termo", "").strip().lower()
        filtro = request.form.get("filtro", "titulo")  # titulo ou autor
        wb, sh = get_sheet()

        registros = list(sh.iter_rows(values_only=True))[1:]
        col_index = 0 if filtro == "titulo" else 1
        valores = [str(r[col_index]) for r in registros]

        similares = difflib.get_close_matches(termo, valores, n=10, cutoff=0.5)

        for row in registros:
            if str(row[col_index]) in similares:
                resultados.append(row)

    return render_template("buscar.html", resultados=resultados, termo=termo, filtro=filtro, headers=HEADERS)

# Editar livro
@app.route("/editar/<int:linha>", methods=["GET", "POST"])
def editar(linha):
    wb, sh = get_sheet()
    dados = [cell.value for cell in sh[linha]]

    if request.method == "POST":
        titulo = request.form.get("titulo", "").strip()
        autor = request.form.get("autor", "").strip()
        ano = request.form.get("ano", "").strip()
        preco = request.form.get("preco", "").strip().replace(",", ".")
        quantidade = request.form.get("quantidade", "").strip()

        if not titulo or not autor:
            flash("Título e Autor são obrigatórios!", "erro")
            return render_template("editar.html", form=request.form, linha=linha)

        try:
            ano = int(ano)
            preco = float(preco)
            quantidade = int(quantidade)
        except:
            flash("Ano, preço ou quantidade inválidos!", "erro")
            return render_template("editar.html", form=request.form, linha=linha)

        for col, val in enumerate([titulo, autor, ano, preco, quantidade], start=1):
            sh.cell(row=linha, column=col, value=val)
        wb.save(EXCEL_FILE)

        flash("Livro atualizado com sucesso!", "sucesso")
        return redirect(url_for("listar"))

    return render_template("editar.html", form={
        "titulo": dados[0],
        "autor": dados[1],
        "ano": dados[2],
        "preco": dados[3],
        "quantidade": dados[4]
    }, linha=linha)

# Excluir livro
@app.route("/excluir/<int:linha>")
def excluir(linha):
    wb, sh = get_sheet()
    sh.delete_rows(linha)
    wb.save(EXCEL_FILE)
    flash("Livro excluído com sucesso!", "sucesso")
    return redirect(url_for("listar"))

# Sugestões (autocomplete)
@app.route("/sugestoes")
def sugestoes():
    termo = request.args.get("q", "").lower()
    filtro = request.args.get("filtro", "titulo")
    wb, sh = get_sheet()

    registros = list(sh.iter_rows(values_only=True))[1:]
    col_index = 0 if filtro == "titulo" else 1
    valores = [str(r[col_index]) for r in registros if r[col_index]]

    if not termo:
        return jsonify([])

    similares = difflib.get_close_matches(termo, [v.lower() for v in valores], n=5, cutoff=0.3)

    sugestoes = []
    for v in valores:
        if v.lower() in similares:
            sugestoes.append(v)

    return jsonify(sugestoes)

# --- Início da aplicação ---
if __name__ == "__main__":
    app.run(debug=True)
